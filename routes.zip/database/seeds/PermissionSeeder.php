<?php

namespace Database\Seeders;

use DB;
use App\Models\Permission;
use Illuminate\Database\Seeder;

class PermissionSeeder extends Seeder{
    public function run()
    {
        DB::table('permissions')->delete();

        Permission::create([
            'id' => '1',
            'title' => 'manageAsset',
        ]);

        Permission::create([
            'id' => '2',
            'title' => 'globalReq',
        ]);

        Permission::create([
            'id' => '3',
            'title' => 'localReq',
        ]);

        Permission::create([
            'id' => '4',
            'title' => 'reportedProb',
        ]);

        Permission::create([
            'id' => '5',
            'title' => 'editAssetNo',
        ]);

        Permission::create([
            'id' => '6',
            'title' => 'reqAsset',
        ]);

        Permission::create([
            'id' => '7',
            'title' => 'assetStat',
        ]);

        Permission::create([
            'id' => '8',
            'title' => 'userHome',
        ]);

    }
}